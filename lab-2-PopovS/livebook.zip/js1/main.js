$('.open-popup1').click(function() {
    $('.popup-bg').fadeIn(600);
});

$('.open-popup2').click(function() {
    $('.popup-gb').fadeIn(600);
});

$('.close-popup').click(function() {
    $('.popup-bg').fadeOut(600);
    $('.popup-gb').fadeOut(600);
});